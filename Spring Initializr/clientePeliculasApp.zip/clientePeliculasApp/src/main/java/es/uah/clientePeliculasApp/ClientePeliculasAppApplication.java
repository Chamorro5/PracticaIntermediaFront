package es.uah.clientePeliculasApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientePeliculasAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientePeliculasAppApplication.class, args);
	}

}
